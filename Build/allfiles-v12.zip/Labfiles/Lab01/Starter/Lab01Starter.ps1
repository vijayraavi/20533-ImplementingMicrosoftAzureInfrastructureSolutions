﻿#Lab 01 Starter script - Using Azure PowerShell

#Variables
$locName = "East US" #Azure datacenter location
$rgName = "TestRG1" # test resource group created in Exercise 2
$newrgName ="TestWebRG" # resource group name to which the storage account will re-assigned
$webappName = "testwebappMMDDYYab" #storage account name. This must be all lower case, and a name that is unique across Azure

#Create a new Web app in the TestRG1 resource group, using the variables above


#View the TestRG1 resource group


#Move the web app to the NewTestRG resource group


#View the NewTestRG resource group resources


#End of script
